<?php get_header(); ?>

	<section class="main-404 full clear-fix">
		<div class="wrapper-main center">
			<h1>Página no encontrada</h1>
			<a href="/" class="btn-home">Volver al inicio</a>
		</div>
	</section>

<?php get_footer(); ?>
