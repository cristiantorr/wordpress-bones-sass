<?php get_header(); ?>
<section class="main-brand full clear-fix">
    <div class="wrapper-main center">
        <figure class="logo-raquel">
            <img src="<?php echo get_stylesheet_directory_uri(). '/library/' ?>images/logo-raquel-munera.png" alt="Logo">
        </figure>
    </div>
</section>
<section class="main-app full clear-fix">
<!-- Banner Desktop -->
    <section class="banner-home relative clear-fix">
        <div class="swiper swiper-banner-home">
            <div class="swiper-wrapper">
                <div class="swiper-slide">
                    <figure class="img-xl">
                        <img src="<?php echo get_stylesheet_directory_uri(). '/library/' ?>images/banner-home-1.png" alt=""> 
                    </figure>
                    <figure class="img-xs">
                        <img src="<?php echo get_stylesheet_directory_uri(). '/library/' ?>images/banner-home-1-xs.png" alt=""> 
                    </figure>
                </div>
                <div class="swiper-slide">
                    <figure class="img-xl">
                        <img src="<?php echo get_stylesheet_directory_uri(). '/library/' ?>images/banner-home-1.png" alt=""> 
                    </figure>
                    <figure class="img-xs">
                        <img src="<?php echo get_stylesheet_directory_uri(). '/library/' ?>images/banner-home-1-xs.png" alt=""> 
                    </figure>
                </div>                
            </div>
        </div>
        <div class="swiper-button-next next-home"></div>
        <div class="swiper-button-prev prev-home"></div>
        <a  href="https://wa.me/+17735400422" target="_blank" class="btn-ws-top">CONTACT HERE</a>
    </section>


    <section id="sobre-el-artista" class="main-artista relative full clear-fix">
        <div class="wrapper-main center relative">
            <div class="grid-colums-two">
                <figure data-aos="fade-up" data-aos-delay="300" data-aos-duration="1000">
                    <img src="<?php echo get_stylesheet_directory_uri(). '/library/' ?>images/foto-1.png" alt=""> 
                </figure>
                <article data-aos="fade-up" data-aos-delay="600" data-aos-duration="1000">
                    <h1>Sobre <br>LA artista</h1>
                    <hr>
                    <p><strong>Soy Raquel Munera, artista y educadora colombiana,</strong> resido actualmente en Chicago. Muchas de las influencias culturales que se evidencian en mi obra, las he recibido como ciudadana estadounidense y por la nacionalidad española otorgada a quienes poseen ancestros sefardíes. He realizado exposiciones individuales y colectivas desde 1982.</p>
                    <p>Mi trabajo artístico más reciente está basado en el manejo de los materiales que encontramos y que se manipulan día a día. <strong> La filosofía que me guía es que el arte se debe ejercer con la misma seriedad con la que un niño juega.</strong> Mis referentes artísticos son numerosos, pero destaco entre ellos a Chaín Soutine, Robert Ryman y Jean Dubuffet.</p>
                </article>
            </div>
        </div>
        <img src="<?php echo get_stylesheet_directory_uri(). '/library/' ?>images/pintura-1.png" alt="" class="pintura-1">
    </section>
    <section class="main-agua relative full clear-fix">
        <div class="wrapper-main center relative">
            <div class="grid-colums-two-agua full relative">
                <article data-aos="fade-up" data-aos-delay="600" data-aos-duration="1000">
                    <div class="title">
                        <img src="<?php echo get_stylesheet_directory_uri(). '/library/' ?>images/como-pez.png" alt="">
                    </div>
                    <div class="caption">
                        <p>Siempre he sentido fascinación por descubrir <strong>lo que se encuentra entre las capas</strong> que configuran las cosas que llegan cada día a nuestras manos y también por las huellas dejadas sobre una superficie cualquiera. <strong> Para comunicar algo distinto al propósito inicial, descontextualizo los empaques e imágenes de revistas y periódicos.</strong></p>
                    </div>
                </article>
                <figure data-aos="fade-up" data-aos-delay="900" data-aos-duration="1000">
                    <img src="<?php echo get_stylesheet_directory_uri(). '/library/' ?>images/pez-3.png" alt="">
                </figure>
            </div>
            <div class="clr"></div>
            <div class="grid-colums-two-pez full relative">
                <div class="title-2" data-aos="fade-right" data-aos-delay="800" data-aos-duration="1000">
                    <img src="<?php echo get_stylesheet_directory_uri(). '/library/' ?>images/tecnica.png" alt="">
                </div>
                <div class="figcaption" data-aos="fade-left" data-aos-delay="800" data-aos-duration="1000">
                    <p><strong>Que consiste en conseguir formas aleatorias sobre diferente superficies</strong> mediante escritura, incisiones o rascados espontáneos con el fin de explorar 
                    las posibilidades plásticas y estéticas que estos sugieren.</p>
                    <p>La obra bidimensional que presento tiene al pez como imagen que se repite en cada obra; <strong>  esto obedece más a una disciplina de trabajo que 
                    a una elección hecha según asociaciones simbólicas o psicológicas.</strong></p>
                </div>
                <img src="<?php echo get_stylesheet_directory_uri(). '/library/' ?>images/pez.png" alt="" class="pez-1 dx-none">
                <img src="<?php echo get_stylesheet_directory_uri(). '/library/' ?>images/pez-2.png" alt="" class="pez-2"> 
            </div>        
        </div>
        <div class="clr"></div>
    
        <img src="<?php echo get_stylesheet_directory_uri(). '/library/' ?>images/mancha-2.png" alt="" class="pintura-2">    
    </section>
    <section class="main-manuscrita relative full clear-fix">
        <div class="wrapper-main-full center relative gallery-card">
            <section class="main-swiper-card clear-fix relative">
                <div class="relative">
                    <div class="swiper swiper-cards">
                        <div class="swiper-wrapper">
                            <div class="swiper-slide">
                                <figure>
                                    <img src="<?php echo get_stylesheet_directory_uri(). '/library/' ?>images/gallery-1.jpg" alt="">
                                </figure>	
                            </div>
                            <div class="swiper-slide">
                                <figure>
                                    <img src="<?php echo get_stylesheet_directory_uri(). '/library/' ?>images/gallery-2.jpg" alt="">
                                </figure>
                            </div>
                            <div class="swiper-slide">
                                <figure>
                                    <img src="<?php echo get_stylesheet_directory_uri(). '/library/' ?>images/gallery-3.jpg" alt="">
                                </figure>
                            </div>
                            <div class="swiper-slide">
                                <figure>
                                    <img src="<?php echo get_stylesheet_directory_uri(). '/library/' ?>images/gallery-2.jpg" alt="">
                                </figure>
                            </div>
                            <div class="swiper-slide">
                                <figure>
                                    <img src="<?php echo get_stylesheet_directory_uri(). '/library/' ?>images/gallery-3.jpg" alt="">
                                </figure>
                            </div>
                        </div>
                    </div>
                    <div class="swiper-button-next next-card next-top"></div>
                    <div class="swiper-button-prev prev-card prev-top"></div>
                </div>
                <div class="swiper-pagination pagination-site pagination-card"></div>
            </section>
        </div>
        <div class="clr"></div>
        <div class="wrapper-main center relative">
            <div class="title-3">
                <img src="<?php echo get_stylesheet_directory_uri(). '/library/' ?>images/la-letra.png" alt="">
            </div>
            <article>
                <p>En la serie <strong> “Como pez en el agua,”</strong> hago un homenaje a la letra manuscrita, que es una marca, una señal exclusiva que identifica y hace visible lo que se siente y lo que se piensa. Aunque los mensajes de texto por el ‘chat’ o por correo electrónico son muy convenientes, no se comparan con algo escrito a mano, porque implica tiempos más lentos y reflexivos. <strong> Los sobres que acompañan la exhibición, proporcionan a los participantes la oportunidad de compartir con otros notas personales como rastros de si mismos.</strong> </p>
            </article>

            <img src="<?php echo get_stylesheet_directory_uri(). '/library/' ?>images/ic-4.png" alt="" class="ornamento-1 dx-none" data-aos="zoom-in" data-aos-delay="600" data-aos-duration="1000">
            <img src="<?php echo get_stylesheet_directory_uri(). '/library/' ?>images/ic-5.png" alt="" class="ornamento-2 dx-none" data-aos="zoom-in" data-aos-delay="800" data-aos-duration="1000">
            <img src="<?php echo get_stylesheet_directory_uri(). '/library/' ?>images/ic-7.png" alt="" class="ornamento-3 dx-none" data-aos="zoom-in" data-aos-delay="1000" data-aos-duration="1000">
            <img src="<?php echo get_stylesheet_directory_uri(). '/library/' ?>images/ic-6.png" alt="" class="ornamento-4 dx-none" data-aos="zoom-in" data-aos-delay="1200" data-aos-duration="1000">
            <img src="<?php echo get_stylesheet_directory_uri(). '/library/' ?>images/ic-8.png" alt="" class="ornamento-5 dx-none" data-aos="fade-down" data-aos-delay="1400" data-aos-duration="1000">
            <img src="<?php echo get_stylesheet_directory_uri(). '/library/' ?>images/mancha-1.png" alt="" class="ornamento-6 dx-none" data-aos="zoom-in" data-aos-delay="1600" data-aos-duration="1000">



        </div>
        <div class="clr"></div>
        <div class="wrapper-main-full center relative gallery-card">
            <section class="main-swiper-gallery clear-fix relative">
                <div class="relative">
                    <div class="swiper swiper-gallery">
                        <div class="swiper-wrapper">
                            <div class="swiper-slide">
                                <figure>
                                    <img src="<?php echo get_stylesheet_directory_uri(). '/library/' ?>images/gallery-4.jpg" alt="">
                                </figure>	
                            </div>
                            <div class="swiper-slide">
                                <figure>
                                    <img src="<?php echo get_stylesheet_directory_uri(). '/library/' ?>images/gallery-5.jpg" alt="">
                                </figure>
                            </div>
                            <div class="swiper-slide">
                                <figure>
                                    <img src="<?php echo get_stylesheet_directory_uri(). '/library/' ?>images/gallery-6.jpg" alt="">
                                </figure>
                            </div>
                            <div class="swiper-slide">
                                <figure>
                                    <img src="<?php echo get_stylesheet_directory_uri(). '/library/' ?>images/gallery-4.jpg" alt="">
                                </figure>
                            </div>
                            <div class="swiper-slide">
                                <figure>
                                    <img src="<?php echo get_stylesheet_directory_uri(). '/library/' ?>images/gallery-5.jpg" alt="">
                                </figure>
                            </div>
                        </div>
                    </div>
                    <div class="swiper-button-next next-card next-gallery"></div>
                    <div class="swiper-button-prev prev-card prev-gallery"></div>
                </div>
                <div class="swiper-pagination pagination-site pagination-gallery"></div>
            </section>
        </div>
    </section>
    <section class="main-have relative full clear-fix">
        <img src="<?php echo get_stylesheet_directory_uri(). '/library/' ?>images/lines.png" alt="" class="lines">    
        <img src="<?php echo get_stylesheet_directory_uri(). '/library/' ?>images/mancha-2.png" alt="" class="pintura-3">    
        <div class="wrapper-main-full center relative">
            <div class="title-4">
                <img src="<?php echo get_stylesheet_directory_uri(). '/library/' ?>images/do-you.png" alt="">      
                <a href="https://wa.me/+17735400422" class="btn-here" target="_blank">CLICK HERE</a>  
            </div>
        </div>
    </section>
    <section id="propuesta-artistica" class="main-propuesta relative full clear-fix">
        <img src="<?php echo get_stylesheet_directory_uri(). '/library/' ?>images/ic-9.png" class="avion" alt="">
        <div class="wrapper-main-full center relative">
            <div class="title-5">
                <img src="<?php echo get_stylesheet_directory_uri(). '/library/' ?>images/propuesta.png" alt="">                  
            </div>
            <div class="grid-colums-propuesta">
                <article>
                    <div class="title-6">
                        <img src="<?php echo get_stylesheet_directory_uri(). '/library/' ?>images/significado.png" alt="">                            
                    </div>                
                    <p><strong>La obra del artista se erige como una reflexión profunda sobre la conexión entre materiales y emociones.</strong> A través de composiciones cuidadosamente elaboradas con retazos de empaques cotidianos, lo desechable se transforma en piezas cargadas de simbolismo. Este proceso creativo, lejos de seguir un plan rígido, es una exploración intuitiva que busca <strong> revelar nuevas texturas, formas y posibilidades visuales.</strong></p>            
                    <p>Cada creación es un homenaje al niño interior que habita en todos nosotros, <strong> invitándonos a mirar más allá de lo evidente y a descubrir la belleza en lo inesperado.</strong> Los materiales, seleccionados con sensibilidad y respeto por sus cualidades, cobran vida en manos del artista, convirtiéndose en un diálogo entre la experiencia, las emociones y las infinitas posibilidades del arte.</p>
                </article>
                <figure>
                    <img src="<?php echo get_stylesheet_directory_uri(). '/library/' ?>images/foto-2.png" alt=""> 
                </figure>
            </div>
        </div>    
    </section>
    <section id="proceso" class="main-proceso relative full clear-fix">
        <div class="wrapper-main center relative">
            <div class="grid-proceso full">
                <figure>
                    <img src="<?php echo get_stylesheet_directory_uri(). '/library/' ?>images/proceso.png" alt=""> 
                </figure>
                <article class="card-video">
                    <figure>
                        <a href="" data-bs-toggle="modal" data-bs-target="#ModalVideo">
                            <img src="<?php echo get_stylesheet_directory_uri(). '/library/' ?>images/video.png" alt=""> 
                        </a>
                    </figure>
                </article>
            </div>
        </div>
        <img src="<?php echo get_stylesheet_directory_uri(). '/library/' ?>images/line-footer.png" alt="" class="lines-footer"> 
    </section>
</section>

<section class="modal fade modal-generico" id="ModalVideo" tabindex="-1" aria-hidden="true">
    <div class="modal-dialog  modal-dialog-centered">
        <div class="modal-content">
            <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
            <iframe  src="https://www.youtube.com/embed/DsvJ7iv_d7Y?si=_2-lV2BfBFNsN75B" title="YouTube video player" frameborder="0" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; web-share" referrerpolicy="strict-origin-when-cross-origin" allowfullscreen></iframe>
        </div>
    </div>
</section>
<?php get_footer(); ?>
