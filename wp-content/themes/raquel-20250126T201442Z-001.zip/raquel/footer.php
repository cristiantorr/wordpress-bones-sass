			<footer class="full">
				<div class="wrapper-main center relative">
					<p>derechos reservados © 2025</p>
					<div class="redes"> 
						<h6>Síguenos</h6>   
						<ul>							
							<li class="icon-it"><a href="" target="_blank">Instagram</a></li>							
							<li class="icon-ws"><a href="https://wa.me/+5700000000" target="_blank">Whatsapp</a></li>
						</ul>
					</div>
					<div class="line-bottom"></div>				
				</div>
			</footer>
				
			<a href="#main-top" class="fixed-top-home">
				<img src="<?php echo get_stylesheet_directory_uri(). '/library/' ?>images/top.png" alt="">
			</a>	


		<?php // all js scripts are loaded in library/bones.php ?>
		<?php wp_footer(); ?>

	</body>

</html> <!-- end of site. what a ride! -->
